--> Project Created on 2nd March 2014 
	
	==> Created by kranthi kumar
--> Spring Version 3.1.1 for Spring Core 
--> Spring Version 3.0.5 for mongodb 
